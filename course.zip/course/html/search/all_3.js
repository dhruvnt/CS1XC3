var searchData=
[
  ['demonstrates_20a_20use_20case_20for_20the_20course_20and_20student_20functions_0',['Demonstrates a use case for the course and student functions',['../index.html',1,'']]]
];
