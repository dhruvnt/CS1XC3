/**
 * @file student.c
 * @author Dhruv Thakor (thakord@mcmaster.ca)
 * @version 0.1
 * @date 2022-04-12
 * @copyright Copyright (c) 2022
 * 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * Will create a dynamic memory array if student only have 1 num_grade,
 * then will add each grade to the array, which will be resized to accomadate for the addition of the new grade 
 * @param student 
 * @param grade 
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));//Will create a dynamic memory array using calloc to hold all student grades once a student has atleast 1 grade to hold
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);//Will resize the dynamic memory array to create space for additional grades
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * Will calculate the average for the specific student by adding all of the student's
 * grades and dividing by the num of total grades. The student's average will be returned.
 * 
 * @param student 
 * @return double 
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;//If the student has no grades, an average of 0 will be returned

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];//For every grade within the students data, the grades are added then divided to return the students average
  return total / ((double) student->num_grades);
}

/**
 * Will print the Name, ID, and Grades for the student.
 * The Average for the student will also be printed using the average function.
 * 
 * @param student 
 */

void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}
/**
 * Will generate a random student name using the first_names and last_names array, each of which contain 24 individual names.
 * Will then strcpy a randomly selected(using random function) first and last name in to a new dynamic memory array for the student.
 * A random student ID(using random function) will also be generated and added to the new_student.
 * Random grades(using random function) will also be generated and added to new_student.
 * The new_student will then be returned with the name, ID, and grades.
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);//using rand() to randomly select a first name
  strcpy(new_student->last_name, last_names[rand() % 24]);//using rand() to randomly select a last name

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);//using rand() to randomly make a student ID and save it to the student's ID data
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));//Creates random grades and adds it to the students data
  }

  return new_student;//Returns the data created for the new student
}