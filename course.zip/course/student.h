/**
 * @file student.h
 * @author Dhruv Thakor (thakord@mcmaster.ca)
 * @brief Student library, used to manage the students and the student functions and student type definition
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */


/**
 * The type student will store a student with first_name, last_name, id, *grades, and num_grades
 * 
 */
typedef struct _student 
{ 
  char first_name[50];/**< The Student's First Name*/
  char last_name[50];/**< The Student's Last Name*/
  char id[11];/**< The Student's ID*/
  double *grades;/**< The Student's Grades*/
  int num_grades;/**< The Number of Student's Grades*/
} Student;

//Different functions created within the student.c file
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
