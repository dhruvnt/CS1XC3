/**
 * @file course.h
 * @author Dhruv Thakor (thakord@mcmaster.ca)
 * @brief  Course library, used to manage the courses and the course functions and course type definition
 * @version 0.1
 * @date 2022-04-12
 * 
 * Creates a typedef struct(Course)
 * Course will hold the students names(char), course code(char), number of total students(int) and a pointer to students 
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>

/**
 * The type course will store a course with name, code, *students, and total_students
 */

typedef struct _course 
{
  char name[100];/**< The Student's Name */
  char code[10];/**< The Course Code */
  Student *students;/**< The students in the course */
  int total_students;/**< Number of total students */
} Course;


//Different functions created within the course.c file and the functions needed from student.c
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


