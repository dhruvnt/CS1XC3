/**
 * @file course.c
 * @author Dhruv Thakor (thakord@mcmaster.ca)
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include "course.h"
#include <stdlib.h>
#include <stdio.h>
/** 
 * Will enroll a specific student in the specified course using the student and course details
 * When the course is first at only 1 enrolled student a dynamic array using Calloc is created with 1 allocated memory space to hold the student information
 * Once the course enrollment exceeds 1, the dynamic array is resized to accomadate space for more students
 * Pointer pointing to the last student enrolled in the course is set to the index of total_students-1
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;//Each time a student is enrolled, the total_students count for hte course will be incrementally increased by 1
  if (course->total_students == 1) //If the course recieved the first student enrollment, a dynamic memory array will be created with calloc with 1 memory block with the size of student
  {
    course->students = calloc(1, sizeof(Student));
  }
  else //For every student after the first the else statement will be executed
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); //The dynamic memory array will be resized using realloc to accomadate for the new student enrollment, and the student details will be added to the array
  }
  course->students[course->total_students - 1] = *student;//The student is then added to the last index within the array
}
/**
 * Function print_course will be used to print the contents within the course
 * It will print Course Name, Course Code, and the total number of students enrolled within course
 * Will then use a for loop to iterate for the number of students enrolled within the course, and will print each student on a new line
 * 
 * @param course 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) //For loop will iterate for the number of students within the course, and will print the students within the course on each new line
    print_student(&course->students[i]);
}

/**
 * If course enrollment is not 0, it will iterate through all students within the course
 * and calculate the average of each student and compate it with max_average
 * to find the top_student within the course. The top_student within the course will be returned as output.
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;//If the course doesn't have any student enrolled NULL is returned as an average cannot be calculated
 
  double student_average = 0;//Student Average Variable is created
  double max_average = average(&course->students[0]);//Max average variable created and set to the placeholder average of the first student within the course
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)//For loop will iterate for the number of students in the course
  {
    student_average = average(&course->students[i]);//The average for the specific student at index i is calculated
    if (student_average > max_average) //If the student has a higher average than the current max_average student, a top student is added
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;//returns the top student
}

/**
 * Will calculate the average for each student by iterating through each enrolled student within the course
 * and check if each student has a grade of either 50 or higher. A dynamic array will then be created using calloc
 * with sizeof(Student) and a specific number of memory blocks, determined by the count of passing studnets. Each passing student
 * will be added to passing array, and the array of passing students will be returned.
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) //Will iterate for every student within the course and will increase the count of the number of passing students if their average is either 50 or over
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));//passing dynamic memory array is created with enough space for thr number of passing students

  int j = 0;
  for (int i = 0; i < course->total_students; i++)//For loop will iterate through every student and will add every passing student into the passing array
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;//total_passing will represent the number of total passing students

  return passing;//returns array of all passing students
}