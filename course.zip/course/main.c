/**
 * @mainpage Demonstrates a use case for the course and student functions
 * The main function will provide a example for how all functions within student.c and course.c function
 * It will demonstrate the use of creating courses, enrolling students, printing courses/students, creating student and course arrays, checking passing/average
 * @file main.c
 * @author Dhruv Thakor (thakord@mcmaster.ca1)
 * @brief creates a demo course and runs the various function to provide an example
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h" 
#include "course.h"


/**
 * Will create a course(MATH101) and generate 20 random students to test each of the different functions within the various files in the folder
 * 
 * @return int 
 */
int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));//Create a course MATH101
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));//Generate random students and enroll them into the MATH101 course
  
  print_course(MATH101);//Uses print_course to print the contents of MATH101

  Student *student;
  student = top_student(MATH101);//Will get the top student form MATH101
  printf("\n\nTop student: \n\n");
  print_student(student);//Uses print_student to print the contents of student(the top student within the course)

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);//Get all passing students within the MATH101 course and the number of total passing students
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);//Print the student information for each passing student within the course
  
  return 0;
}